insert into tipos_telefones values (1,'Residencial');
insert into tipos_telefones values (2,'Comercial');
insert into tipos_telefones values (3,'Celular');
insert into tipos_telefones values (4,'Recados');
insert into tipos_telefones values (5,'Outros');






